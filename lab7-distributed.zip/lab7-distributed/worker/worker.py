import pika
import json
import os
import psycopg2
import time

RABBITMQ_HOST = os.getenv("RABBITMQ_HOST", "rabbitmq")

DB_HOST = os.getenv("DB_HOST", "db")
DB_PORT = os.getenv("DB_PORT", "5432")
DB_NAME = os.getenv("DB_NAME", "secure_system")
DB_USER = os.getenv("DB_USER", "postgres")
DB_PASSWORD = os.getenv("DB_PASSWORD", "postgres")

SERVICE_NAME = os.getenv("SERVICE_NAME", "worker")
SERVICE_AUTH_TOKEN = os.getenv("SERVICE_AUTH_TOKEN", "internal-secret")


def get_db_connection():
    return psycopg2.connect(
        host=DB_HOST,
        port=DB_PORT,
        database=DB_NAME,
        user=DB_USER,
        password=DB_PASSWORD
    )


def log_event(request_id, action, status, source):
    conn = get_db_connection()
    cur = conn.cursor()

    cur.execute("""
        INSERT INTO audit_logs (service_name, request_id, action_performed, status, source)
        VALUES (%s, %s, %s, %s, %s)
    """, (SERVICE_NAME, request_id, action, status, source))

    conn.commit()
    cur.close()
    conn.close()


def log_state(request_id, state):
    conn = get_db_connection()
    cur = conn.cursor()

    cur.execute("""
        INSERT INTO request_states (request_id, state)
        VALUES (%s, %s)
    """, (request_id, state))

    conn.commit()
    cur.close()
    conn.close()


def callback(ch, method, properties, body):
    request_id = None
    try:
        data = json.loads(body)
        request_id = data.get("request_id")

        if not request_id:
            print("[ERROR] Missing request_id in message")
            ch.basic_nack(delivery_tag=method.delivery_tag, requeue=False)
            return

        if data.get("auth_token") != SERVICE_AUTH_TOKEN:
            log_event(request_id, "Unauthorized service access", "failure", "service")
            log_state(request_id, "FAILED")
            ch.basic_ack(delivery_tag=method.delivery_tag)
            return

        log_event(request_id, "Message consumed from queue", "success", "service")
        log_state(request_id, "CONSUMED")

        print("Processing task from:", data.get("from"))

        # Simulate processing
        log_event(request_id, "Task processed successfully", "success", "service")
        log_state(request_id, "PROCESSED")

        ch.basic_ack(delivery_tag=method.delivery_tag)

    except Exception as e:
        print("Error:", str(e))

        if request_id:
            log_event(request_id, f"Error: {str(e)}", "failure", "service")
            log_state(request_id, "FAILED")

        ch.basic_nack(delivery_tag=method.delivery_tag, requeue=False)


def connect_rabbitmq():
    while True:
        try:
            connection = pika.BlockingConnection(
                pika.ConnectionParameters(RABBITMQ_HOST)
            )
            return connection
        except Exception as e:
            print(f"RabbitMQ not ready, retrying... {e}")
            time.sleep(5)


connection = connect_rabbitmq()
channel = connection.channel()
channel.queue_declare(queue="tasks")

channel.basic_consume(
    queue="tasks",
    on_message_callback=callback,
    auto_ack=False
)

print("Worker started...")
channel.start_consuming()
