from fastapi import FastAPI, Request, HTTPException
import jwt
import pika
import json
import socket
import uuid
import os
import psycopg2

app = FastAPI()

SECRET = os.getenv("JWT_SECRET", "supersecret")
RABBITMQ_HOST = os.getenv("RABBITMQ_HOST", "rabbitmq")
SERVICE_NAME = os.getenv("SERVICE_NAME", "api")

DB_HOST = os.getenv("DB_HOST", "db")
DB_PORT = os.getenv("DB_PORT", "5432")
DB_NAME = os.getenv("DB_NAME", "secure_system")
DB_USER = os.getenv("DB_USER", "postgres")
DB_PASSWORD = os.getenv("DB_PASSWORD", "postgres")

SERVICE_AUTH_TOKEN = os.getenv("SERVICE_AUTH_TOKEN", "internal-secret")


def get_db_connection():
    return psycopg2.connect(
        host=DB_HOST,
        port=DB_PORT,
        database=DB_NAME,
        user=DB_USER,
        password=DB_PASSWORD
    )


def verify_token(request: Request):
    auth = request.headers.get("Authorization")

    if not auth:
        raise HTTPException(status_code=403, detail="Missing token")

    parts = auth.split(" ")
    if len(parts) != 2 or parts[0].lower() != "bearer":
        raise HTTPException(status_code=403, detail="Invalid authorization format")

    token = parts[1]

    try:
        payload = jwt.decode(token, SECRET, algorithms=["HS256"])
        return payload
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=403, detail="Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=403, detail="Invalid token")


def log_event(request_id, action, status, source):
    conn = get_db_connection()
    cur = conn.cursor()

    cur.execute(
        """
        INSERT INTO audit_logs (service_name, request_id, action_performed, status, source)
        VALUES (%s, %s, %s, %s, %s)
        """,
        (SERVICE_NAME, request_id, action, status, source)
    )

    conn.commit()
    cur.close()
    conn.close()


def log_state(request_id, state):
    conn = get_db_connection()
    cur = conn.cursor()

    cur.execute(
        """
        INSERT INTO request_states (request_id, state)
        VALUES (%s, %s)
        """,
        (request_id, state)
    )

    conn.commit()
    cur.close()
    conn.close()

@app.get("/health")
def health():
    return {
        "status": "ok",
        "service": SERVICE_NAME
    }

@app.get("/task")
def task(request: Request):
    hostname = socket.gethostname()

    request_id = request.headers.get("X-Request-ID")
    if not request_id:
        request_id = str(uuid.uuid4())

    try:
        log_event(
            request_id=request_id,
            action=f"Request received by {hostname}",
            status="success",
            source="client"
        )
        log_state(request_id, "RECEIVED")

        payload = verify_token(request)

        log_event(
            request_id=request_id,
            action="JWT validated",
            status="success",
            source="client"
        )
        log_state(request_id, "AUTHENTICATED")

        connection = pika.BlockingConnection(
            pika.ConnectionParameters(RABBITMQ_HOST)
        )
        channel = connection.channel()
        channel.queue_declare(queue="tasks")

        message = {
            "request_id": request_id,
            "service": payload.get("service", "api"),
            "from": hostname,
            "source_service": SERVICE_NAME,
            "auth_token": SERVICE_AUTH_TOKEN
        }

        channel.basic_publish(
            exchange="",
            routing_key="tasks",
            body=json.dumps(message)
        )

        connection.close()

        log_event(
            request_id=request_id,
            action="Task sent to RabbitMQ",
            status="success",
            source="service"
        )
        log_state(request_id, "QUEUED")

        return {
            "status": "task sent",
            "handled_by": hostname,
            "request_id": request_id
        }

    except HTTPException:
        log_event(
            request_id=request_id,
            action="Authentication failed",
            status="failure",
            source="client"
        )
        log_state(request_id, "FAILED")
        raise

    except Exception as e:
        log_event(
            request_id=request_id,
            action=f"Internal error: {str(e)}",
            status="failure",
            source="service"
        )
        log_state(request_id, "FAILED")
        raise HTTPException(status_code=500, detail="Internal server error")
